package KeywordsSearch;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.mongodb.AggregationOutput;

import WekaIntegration.CsvToArff;
import WekaIntegration.loadmodel;


@Path("/predictKeywords")

public class jsonKeywords{

	 String keyword;
	 KeywordsSearch ks=new KeywordsSearch();
	 Keyword_Methods km=new Keyword_Methods();
		 Gson gson = new Gson();
	
	@GET
	@Path("{keyword}")	
	@Produces(MediaType.APPLICATION_JSON)

	public  String getTrackInJSON(@PathParam("keyword") String year) throws Exception  {
		
		System.out.println("ahsdjashdjahsdjh"+keyword);
		AggregationOutput op=ks.Keyword_MongoDB(keyword);
		
	
		
	String jsonInString = gson.toJson(op);
	System.out.println(jsonInString);
		return jsonInString;
	}
	
	@POST
	@Path("/post")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response createTrackInJSON(Keyword_Methods data) {

	String result = "data saved : " + data;
		return Response.status(201).entity(result).build();
	}		
	}
	
