package WekaIntegration;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import weka.classifiers.Classifier;
import weka.classifiers.functions.*;
import weka.classifiers.functions.supportVector.NormalizedPolyKernel;
import weka.classifiers.functions.supportVector.RBFKernel;
import weka.classifiers.functions.supportVector.RegSMOImproved;
import weka.classifiers.meta.Stacking;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.Remove;


public class builtmodel {
	public static void main(String args[]) throws Exception {
		Stacking  sr=new Stacking();
		GaussianProcesses gp=new GaussianProcesses(); 
		RBFKernel nr=new RBFKernel();
	       gp.setKernel(nr); 
	       SMOreg sm=null;
	       
		sr.setMetaClassifier(gp);
		Classifier[] nn={
				sm=new SMOreg()	,
			new GaussianProcesses()
		} ;
		
sr.setClassifiers(nn);
		Instances inst = new Instances(
				new BufferedReader(new FileReader("D:/KID/KIIDTrainData.arff")));
		
		inst.setClassIndex(inst.numAttributes() - 1);
		sr.buildClassifier(inst);
		weka.core.SerializationHelper.write("D:/KID/KIDModel.model", sr);
System.out.println(sr);
		
	}
}
