package WekaIntegration;


import com.cts.cs.rest.FundsComparison;
import com.cts.cs.rest.cmparisonfile;
import com.cts.cs.rest.jsonservices;

import mongo.Fetch_mongoDB_Data;

public class mainClass {

	public static void main(String[] args) throws Exception {
	//System.out.println("hello");
//	jsonGraphs js=new jsonGraphs();
	//System.out.println(js.getTrackInJSON());
	//jsonservices js=new jsonservices();
	//System.out.println(js.getTrackInJSON(2016, 3));
		//Fetch_mongoDB_Data ft=new Fetch_mongoDB_Data();
		//System.out.println(ft.graphs());
	//	predictFunds ff=new predictFunds();
		//System.out.println(ff.PredictedQuaterReturn());
FundsComparison fd=new FundsComparison();
fd.getTrackInJSON(2016);
	}

}
