package WekaIntegration;

import weka.classifiers.functions.GaussianProcesses;


import weka.classifiers.functions.supportVector.RBFKernel;


import weka.core.Instance;
import weka.core.Instances;

import weka.core.converters.ConverterUtils.DataSource;

public class predictFunds {

		@SuppressWarnings("null")
		public double[] PredictedQuaterReturn() throws Exception {
			GaussianProcesses gp=new GaussianProcesses(); 
			RBFKernel nr=new RBFKernel();
		       gp.setKernel(nr); 
		       
		
			System.out.println("loading model");
			
	gp= (GaussianProcesses) weka.core.SerializationHelper.read("D:/KID/FundsTrainDataModel.model");

	double nbpred[] = new double[100];

			DataSource src2 = new DataSource("D:/KID/Test.arff");
		
			Instances testdata11 = src2.getDataSet();
			
			testdata11.setClassIndex(testdata11.numAttributes() - 1);

			for (int i = 0; i < testdata11.numInstances(); i++) {

				double actualClass = testdata11.instance(i).classValue();

				@SuppressWarnings("unused")
				String actual = testdata11.classAttribute().value((int) actualClass);

				Instance inst = testdata11.instance(i);
				System.out.println(gp.classifyInstance(inst));
				nbpred[i]=gp.classifyInstance(inst);
				
				System.out.println(nbpred);

			}
		
	testdata11.delete();
			return nbpred;

		}
		



}
