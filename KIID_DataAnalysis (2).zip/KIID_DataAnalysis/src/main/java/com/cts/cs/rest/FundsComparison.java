package com.cts.cs.rest;


import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;


import KeywordsSearch.Keyword_Methods;
import KeywordsSearch.KeywordsSearch;

@Path("/comparison")
public class FundsComparison {



		 String keyword;
		 KeywordsSearch ks=new KeywordsSearch();
		 Keyword_Methods km=new Keyword_Methods();
			 Gson gson = new Gson();
		
		@GET
		@Path("{year}")	
		@Produces(MediaType.APPLICATION_JSON)

		public  String getTrackInJSON(@PathParam("year") int year) throws Exception  {
			
		System.out.println("hello");
			 cmparisonfile cf=new cmparisonfile();
			 
	ArrayList file=	 cf.fetchdata(year);
		System.out.println("sdjefklsjdk");
			classmethods cm=new classmethods();
			System.out.println("abaccc");
			//cm.setQuarterReturn(file.get(1));
			String jsonInString = gson.toJson(file);
			
			System.out.println(file.size());
		/*	for(int i=0;i<file.size();i++)
			{
 jsonInString = gson.toJson(file.get(i));

		System.out.println("-----"+jsonInString);
			}*/
			System.out.println(jsonInString);
			return jsonInString;
		}
		
		@POST
		@Path("/post")
		@Consumes(MediaType.APPLICATION_JSON)
		public Response createTrackInJSON(Keyword_Methods data) {

		String result = "data saved : " + data;
			return Response.status(201).entity(result).build();
		}		
	}