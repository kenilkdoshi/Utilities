package com.cts.cs.rest;

import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.mongodb.DBCursor;
import com.mongodb.util.JSON;

import mongo.Fetch_mongoDB_Data;
import mongo.hello;
@Path("/graphs")

public class Graphs {


	
		 
		 Gson gson = new Gson();
		
		
		@GET
		@Path("/pie")	
		@Produces(MediaType.APPLICATION_JSON)

		public  String getTrackInJSON() throws Exception  {
			System.out.println("hdfjkjsdjf");
		hello hh=new hello();
	DBCursor dc=	hh.plot();
	JSON json =new JSON();
    String serialize = json.serialize(dc);
			System.out.println("kdjfksjdkfs");
			return serialize;
		}
		
		@POST
		@Path("/post")
		@Consumes(MediaType.APPLICATION_JSON)
		public Response createTrackInJSON(classmethods data) {

		String result = "data saved : " + data;
			return Response.status(201).entity(result).build();
		}		
		}
		


