package com.cts.cs.rest;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import WekaIntegration.CsvToArff;
import WekaIntegration.loadmodel;

public class RestToWeka {
	public double RestToWeka(int yr,int q) throws Exception
	{ 
	
			File file = new File("D:/KID/KIDTestData.csv");
			
			BufferedWriter bw = new BufferedWriter(new FileWriter(file.getAbsoluteFile()));
			
			String cn = "Year" + "," + "Qatyer" + "," + "Sharep" + "," +"Perform"+ "," +"QuarterRet";
				
			bw.append(cn);
			bw.newLine();
			String content = yr + "," + q + "," + "?" + "," +"?"+","+"?";
			bw.append(content);
			bw.newLine();
			bw.close();
			
			CsvToArff cst=new CsvToArff();
			System.out.println("---------------");
			
			cst.fileconversion();
			loadmodel lm=new loadmodel();
			double r=lm.PredictedQuaterReturn();
			
		return r;
		
	}

}
