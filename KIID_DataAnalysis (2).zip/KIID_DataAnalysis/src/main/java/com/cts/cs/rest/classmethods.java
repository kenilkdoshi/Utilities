package com.cts.cs.rest;

import java.util.ArrayList;
import java.util.List;

public class classmethods {
double quarterReturn;
String shareName;



public String getShareName() {
	return shareName;
}

public void setShareName(String shareName) {
	this.shareName = shareName;
}

/*
int year;

public int getYear() {
	return year;
}

public void setYear(int year) {
	this.year = year;
}
*/
public double getQuarterReturn() {
	return quarterReturn;
}

public void setQuarterReturn(double quarterReturn) {
	this.quarterReturn = quarterReturn;
}


}
