package com.cts.cs.rest;

import java.awt.List;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import WekaIntegration.CsvToArff;
import WekaIntegration.loadmodel;
import WekaIntegration.predictFunds;

public class cmparisonfile {
	ArrayList arr=new ArrayList<>();
	@SuppressWarnings("deprecation")
	public ArrayList fetchdata(int year) throws Exception
	{
		
	List l=new List();
		
l.addItem("BlackRock Japan Index Sub-Fund");
l.addItem("BlackRock North America Index Sub-Fund");
l.addItem("BlackRock Pacific Index Sub-Fund");
l.addItem("Emerging Markets Corporate Bond Fund");
l.addItem("European Equity Income Fund");
l.addItem("Global Inflation Linked Bond Fund");
		File file = new File("D:/KID/TestDataForAllShares.csv");
		int i=0;
		BufferedWriter bw = new BufferedWriter(new FileWriter(file.getAbsoluteFile()));
	
		String cn = "Fund" + "," + "Year" + "," + "Actual" + "," +"Benchmark";
			
		bw.append(cn);
		bw.newLine();
		int x=l.getItemCount();
		while(x!=0)
		{
			System.out.println(x+"------"+l.getItem(i));
		String content =l.getItem(i)  + "," + year + "," + "?" + "," +"?";
		bw.append(content);
		bw.newLine();
		i++;
		x--;
		}
		bw.close();
		
		fileconversion2 fc=new fileconversion2();
		
		int y=l.getItemCount();
fc.convert();
		
		int j=0,k=0;
		while(y!=0)
		{ classmethods cm=new classmethods();
		predictFunds pf=new predictFunds();
		double[] r=pf.PredictedQuaterReturn();
			System.out.println("-----------------"+l.getItem(j)+r[j]);
			cm.setShareName(l.getItem(j));
			cm.setQuarterReturn(r[j]);
			arr.add(k, cm);

			j++;
			y--;
			k++;
					}
		


	return arr;
}

	}

