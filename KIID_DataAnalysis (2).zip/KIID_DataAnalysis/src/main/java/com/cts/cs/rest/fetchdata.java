package com.cts.cs.rest;
import java.sql.*;
import java.util.ArrayList;
import java.util.List; 
public class fetchdata {
	
 
	ArrayList<classmethods> customerList=null;
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ArrayList<classmethods> graphs(){  
	try{  
	Class.forName("com.mysql.jdbc.Driver");  
	Connection con=DriverManager.getConnection(  "jdbc:mysql://localhost:3306/kiid","root","root");  
	//here sonoo is database name, root is username and password  
	Statement stmt=con.createStatement();  
	customerList=new ArrayList<>();
ResultSet rs=stmt.executeQuery("select * from sharedata");  



while (rs.next()) {
	classmethods cmd=new classmethods();
	int y=rs.getInt("year");
	double s=rs.getDouble("quaterRet");
	System.out.println(y+"   "+s);
//cmd.setYear(y);
cmd.setQuarterReturn(s);
customerList.add(cmd);
}

/*for(int i=0;i<customerList.size();i++)
{
	classmethods cmd2=(classmethods)customerList.get(i);
	System.out.println(cmd2.getQuarterReturn());
}*/
	con.close();  
	}catch(Exception e){ System.out.println(e);}
	
	return customerList;
	}  
	
	}  

