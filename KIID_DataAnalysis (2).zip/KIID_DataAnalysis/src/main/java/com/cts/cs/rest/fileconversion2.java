package com.cts.cs.rest;

import java.io.File;
import java.io.IOException;

import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;

public class fileconversion2 {
public void convert() throws IOException
{
	CSVLoader c = new CSVLoader();
	c.setSource(new File("D:/KID/TestDataForAllShares.csv"));
	Instances data = c.getDataSet();
	//File file = new File("D:/KID/KIDTestData.arff");
	
	ArffSaver saver = new ArffSaver();
	saver.setInstances(data);
	saver.setFile( new File("D:/KID/TestDataForAllShares.arff"));
	saver.writeBatch();
}
}
