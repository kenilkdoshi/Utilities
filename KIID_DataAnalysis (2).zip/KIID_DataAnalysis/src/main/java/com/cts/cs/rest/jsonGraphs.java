package com.cts.cs.rest;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import WekaIntegration.CsvToArff;
import WekaIntegration.loadmodel;
import mongo.Fetch_mongoDB_Data;
//@Path("/graphs")
//public class jsonGraphs {

	/* int year,quater;
	Fetch_mongoDB_Data fd=new Fetch_mongoDB_Data();
	classmethods cm=new classmethods();
	 
	 Gson gson = new Gson();
	
	
	@GET
	@Path("/pie")	
	@Produces(MediaType.APPLICATION_JSON)

	public  String getTrackInJSON() throws Exception  {
		System.out.println("sdjfklsjd");
	ShareData_DAO cmd=new ShareData_DAO();
		ArrayList<ShareData_DAO> list = new ArrayList<>();
	list=(ArrayList<ShareData_DAO>)fd.graphs();
		for(int i=0;i<list.size();i++)
		{
cmd=list.get(i);
System.out.println(cmd.getQuarterReturn());
		
		
		}
		String jsonInString = gson.toJson(list);
	System.out.println(jsonInString);
		return jsonInString;
	}
	
	@POST
	@Path("/post")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response createTrackInJSON(classmethods data) {

	String result = "data saved : " + data;
		return Response.status(201).entity(result).build();
	}		
	}
	
*/