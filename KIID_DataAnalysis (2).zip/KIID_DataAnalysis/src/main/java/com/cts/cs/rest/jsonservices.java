package com.cts.cs.rest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;

import WekaIntegration.CsvToArff;
import WekaIntegration.loadmodel;


@Path("/prediction")

public class jsonservices {

	 int year,quater;
	RestToWeka rtw=new RestToWeka();
	classmethods cm=new classmethods();
	 
	 Gson gson = new Gson();
	
	@GET
	@Path("{year}/{quater}")	
	@Produces(MediaType.APPLICATION_JSON)

	public  String getTrackInJSON(@PathParam("year") int year,@PathParam("quater") int quater) throws Exception  {
		
	System.out.println("dfjksd");
		double qr=rtw.RestToWeka(year,quater);
		
		cm.setQuarterReturn(qr);
		
	String jsonInString = gson.toJson(cm);
	System.out.println(jsonInString);
		return jsonInString;
	}
	
	@POST
	@Path("/post")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response createTrackInJSON(classmethods data) {

	String result = "data saved : " + data;
		return Response.status(201).entity(result).build();
	}		
	}
	
