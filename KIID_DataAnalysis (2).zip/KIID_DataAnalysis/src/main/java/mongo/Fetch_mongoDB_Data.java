	package mongo;

	import java.util.ArrayList;

import com.cts.cs.rest.ShareData_DAO;

	import com.mongodb.DB;
	import com.mongodb.DBCollection;
	import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

public class Fetch_mongoDB_Data {

	DBObject dboj=null;

	ArrayList<ShareData_DAO> list=null;
	public DBObject  graphs() {
			 try
			 {
			 
			  // To connect to mongodb server
	         @SuppressWarnings("resource")
			MongoClient mongoClient =new MongoClient("localhost", 27017 );
				
	         // Now connect to your databases
	         DB db = mongoClient.getDB( "KIID_DB" );
	         System.out.println("Connect to database successfully"+db);
	         //DBCollection coll = db.createCollection("sharedata", null);
	         System.out.println("Collection created successfully");
				
	         DBCollection  coll = db.getCollection("sharedata");
	         System.out.println("Collection mycol selected successfully"+coll);
	        list=new ArrayList<>();
	         DBCursor cursor = coll.find();
	         int i = 1;
				         while (cursor.hasNext()) { 
	        	dboj=cursor.next();
	        	/*ShareData_DAO cmd=new ShareData_DAO();
	           System.out.println("-----------");
	    
	        cmd.setYear(Integer.parseInt(cursor.next().get("Year").toString()));
	        	cmd.setQuarterReturn(Double.parseDouble(cursor.next().get("QuarterRet").toString()));
	        	list.add(cmd);
	 */
	            i++;
	         }
	     
	       System.out.println(dboj);
		 }
	catch(Exception e)
			 {
		System.out.println(e);
			 }
			return dboj;
	}
	}
