package mongo;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;

public class abcd {
	 public static void main(String[] args ) {
		 try
		 {
		 System.out.println("dhfsjkh");
		  // To connect to mongodb server
         MongoClient mongoClient =new MongoClient("localhost", 27017 );
			
         // Now connect to your databases
         DB db = mongoClient.getDB( "KIID_DB" );
         System.out.println("Connect to database successfully"+db);
         //DBCollection coll = db.createCollection("sharedata", null);
         System.out.println("Collection created successfully");
			
         DBCollection  coll = db.getCollection("sharedata");
         
         System.out.println("Collection mycol selected successfully"+coll);
         System.out.println("sdnfjsnhj");
         /*BasicDBObject doc = new BasicDBObject("Year", " ").
                 append("Qatyer", " ").
                 append("Sharep"," ").
                 append("Perform", " ").
                 append("QuarterRet", " ");
         System.out.println("sdnfjsnhj");
			*/
         //coll.insert(doc);
 		
         DBCursor cursor = coll.find();
         int i = 1;
			
         while (cursor.hasNext()) { 
        	 
            System.out.println("Inserted Document: "+i); 
            System.out.println(cursor.next()); 
            i++;
         }
       //  System.out.println("Document inserted successfully"+coll);
       
	 }
catch(Exception e)
		 {
	System.out.println("sdfjskjd");
		 }
}
}
