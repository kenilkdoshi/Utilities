package mongo;




import com.mongodb.DB;

import com.mongodb.MongoClient;

import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.util.JSON;

import java.net.UnknownHostException;
public class hello {
	DBCursor cursor=null;
   public DBCursor plot(){	
	 

	
	          
	            MongoClient mongoClient;
	            String host= "localhost";
	            int port=27017;
	            String dbName="KIID_DB";
	           mongoClient = new MongoClient(host,port);
			  DBCollection collection = mongoClient.getDB(dbName).getCollection("sharedata");
			 cursor = collection.find();
			 System.out.println(cursor);
			JSON json =new JSON();
         String serialize = json.serialize(cursor);
         System.out.println(serialize);
		return cursor;
        
	       }
	         
	   
   
}