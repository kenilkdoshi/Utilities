package KeywordsSearch;

import com.mongodb.MongoClient;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;



public class KeywordsSearch {
	
	AggregationOutput output=null;
	  @SuppressWarnings({ "unused", "deprecation" })
	public AggregationOutput Keyword_MongoDB(String word) {
		  
	      try{
	 
	         // To connect to mongodb server
	         @SuppressWarnings("resource")
	MongoClient mongoClient = new MongoClient( "localhost" , 27017 );
	 
	         // Now connect to your databases
	         DB db = mongoClient.getDB( "KIID_DB" );   //databse name in command prompt
	         System.out.println("Connected to database successfully");
	       
	         DBCollection coll = db.getCollection("Keywords");
	         System.out.println("Collection Keywords selected successfully");
	        	                  
	         //BasicDBObject whereQuery = new BasicDBObject();
	         //BasicDBObject andQuery = new BasicDBObject();
	        //List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
	         
	         //obj.add(new BasicDBObject("Action"));
	        // obj.add(new BasicDBObject("Name_of_doc", " "));
	         //obj.add(new BasicDBObject("Region", "Japan"));
	      
	        DBObject matchFields = new BasicDBObject();
	        matchFields.put("Keywords",word);
	        matchFields.put("Action","Download");
	        DBObject match = new BasicDBObject("$match", matchFields );
	        
	           
	        
	       DBObject groupFields = new BasicDBObject( "_id", "$Name_of_doc");
	       groupFields.put("Count", new BasicDBObject( "$sum", 1));
	       DBObject group = new BasicDBObject("$group", groupFields );
	       
	       
	       DBObject matchFields1 = new BasicDBObject();
	       //matchFields1.put("Keywords","FDI");
	       matchFields1.put("Action","Download");
	       
	      DBObject match1 = new BasicDBObject("$match", matchFields1 );
	       
	       DBObject groupFields1 = new BasicDBObject( "_id", "$Name_of_doc");
	       groupFields.put("Count", new BasicDBObject( "$sum", 1));
	       DBObject group1 = new BasicDBObject("$group", groupFields );
	       
	       
	        DBObject sortFields = new BasicDBObject("Count", -1);
	        DBObject sort = new BasicDBObject("$sort", sortFields );
	        
	         
	 output = coll.aggregate(match,group,sort);
	       
	        
	            
	        System.out.println("INSERted");
	 
	      }catch(Exception e){
	         System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      }
		return output;
	   }
	}	
	


