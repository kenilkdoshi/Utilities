package KeywordsSearch;

public class keyword_main {
	public static void main(String args[]) throws Exception
	{
		//jsonKeywords jk=new jsonKeywords();
		//System.out.println("abbbb----------"+jk.getTrackInJSON("FDI"));
		//Keyword_MongoDB km=new Keyword_MongoDB();
		//km.
	}

}
