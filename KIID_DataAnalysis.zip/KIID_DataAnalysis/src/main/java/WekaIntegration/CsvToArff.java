package WekaIntegration;

import java.io.File;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;

public class CsvToArff
{
	
	public void fileconversion() throws Exception 
	{
		CSVLoader c = new CSVLoader();
		c.setSource(new File("D:/KID/KIDTestData.csv"));
		Instances data = c.getDataSet();
		//File file = new File("D:/KID/KIDTestData.arff");
		
		ArffSaver saver = new ArffSaver();
		saver.setInstances(data);
		saver.setFile( new File("D:/KID/KIDTestData.arff"));
		saver.writeBatch();
		

	}

}
