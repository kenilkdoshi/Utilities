package WekaIntegration;

import java.io.BufferedReader;
import java.io.FileReader;

import weka.classifiers.functions.*;

import weka.classifiers.functions.supportVector.RBFKernel;

import weka.core.Instances;

public class builtModelForFunds {

		public static void main(String args[]) throws Exception {
			
			GaussianProcesses gp=new GaussianProcesses(); 
		RBFKernel nr=new RBFKernel();
		    gp.setKernel(nr); 
		    
			Instances inst = new Instances(new BufferedReader(new FileReader("D:/KID/AllFundsDetails.arff")));
			
			inst.setClassIndex(inst.numAttributes() - 1);
		gp.buildClassifier(inst);
			weka.core.SerializationHelper.write("D:/KID/AllFundsDetailsModel.model", gp);
	System.out.println(gp);
			
		}


}
