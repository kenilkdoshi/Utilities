package WekaIntegration;


import weka.classifiers.Classifier;
import weka.classifiers.functions.GaussianProcesses;
import weka.classifiers.functions.SMOreg;

import weka.classifiers.functions.supportVector.RBFKernel;
import weka.classifiers.functions.supportVector.RegSMOImproved;
import weka.classifiers.meta.Stacking;

import weka.core.Instance;
import weka.core.Instances;

import weka.core.converters.ConverterUtils.DataSource;

public class loadmodel {

	public double PredictedQuaterReturn() throws Exception {
		Stacking  sr=new Stacking();
		GaussianProcesses gp=new GaussianProcesses(); 
		RBFKernel nr=new RBFKernel();
	gp.setKernel(nr);
		sr.setMetaClassifier(gp);
		SMOreg sm=null;
	       
		sr.setMetaClassifier(gp);
		Classifier[] nn={
				sm=new SMOreg()	,
			new GaussianProcesses()
		} ;
		sm.setKernel(new RBFKernel());
	       sm.setRegOptimizer(new RegSMOImproved());

		System.out.println("loading model");
		sr.setClassifiers(nn);
sr= (Stacking) weka.core.SerializationHelper.read("D:/KID/KIDModel.model");

		double nbpred = 0;

		DataSource src2 = new DataSource("D:/KID/KIDTestData.arff");
	
		Instances testdata11 = src2.getDataSet();
		
		testdata11.setClassIndex(testdata11.numAttributes() - 1);

		for (int i = 0; i < testdata11.numInstances(); i++) {

			double actualClass = testdata11.instance(i).classValue();

			@SuppressWarnings("unused")
			String actual = testdata11.classAttribute().value((int) actualClass);

			Instance inst = testdata11.instance(i);
			
			nbpred =sr.classifyInstance(inst);
			System.out.println(nbpred);

		}
	
testdata11.delete();
		return nbpred;

	}
	
	
	
	
}
