package WekaIntegration;

import java.util.ArrayList;

import weka.classifiers.functions.GaussianProcesses;


import weka.classifiers.functions.supportVector.RBFKernel;


import weka.core.Instance;
import weka.core.Instances;

import weka.core.converters.ConverterUtils.DataSource;

public class predictFunds {
	
	ArrayList<Double> nbpred =  new ArrayList<Double>();
		public ArrayList<Double> PredictedQuaterReturn() throws Exception {
			GaussianProcesses gp=new GaussianProcesses(); 
			RBFKernel nr=new RBFKernel();
		       gp.setKernel(nr); 
		       
			System.out.println("loading model");
			gp= (GaussianProcesses) weka.core.SerializationHelper.read("D:/KID/FundsTrainDataModel.model");

	
			DataSource src2 = new DataSource("D:/KID/TestDataForAllShares.arff");
		
			Instances testdata11 = src2.getDataSet();
			
			testdata11.setClassIndex(testdata11.numAttributes() - 1);

			for (int i = 0; i < testdata11.numInstances(); i++) {

				double actualClass = testdata11.instance(i).classValue();

				@SuppressWarnings("unused")
				String actual = testdata11.classAttribute().value((int) actualClass);

				Instance inst = testdata11.instance(i);
			//	System.out.println(gp.classifyInstance(inst));
				nbpred.add(gp.classifyInstance(inst));
				
				//System.out.println("------"+nbpred);

			}
		
	testdata11.delete();
			return nbpred;

		}
		



}
