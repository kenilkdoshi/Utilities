package com.cts.cs.rest;


import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;


import KeywordsSearch.Keyword_Methods;
import KeywordsSearch.KeywordsSearch;

@Path("/comparison")
public class FundsComparison {



		 
		
			 Gson gson = new Gson();
		
		@GET
		@Path("{year}")	
		@Produces(MediaType.APPLICATION_JSON)

		public  String getTrackInJSON(@PathParam("year") int year) throws Exception  {
			
		System.out.println("hello");
			 cmparisonfile cf=new cmparisonfile();
			 
	@SuppressWarnings("rawtypes")
	ArrayList file=	 cf.fetchdata(year);
		String jsonInString = gson.toJson(file);
			System.out.println("json"+jsonInString);
					return jsonInString;
		}
		
		@POST
		@Path("/post")
		@Consumes(MediaType.APPLICATION_JSON)
		public Response createTrackInJSON(Keyword_Methods data) {

		String result = "data saved : " + data;
			return Response.status(201).entity(result).build();
		}		
	}