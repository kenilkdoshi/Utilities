package com.cts.cs.rest;

public class ShareData_DAO {


	double quarterReturn;

	int year;

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}
	
	public double getQuarterReturn() {
		return quarterReturn;
	}

	public void setQuarterReturn(double quarterReturn) {
		this.quarterReturn = quarterReturn;
	}


	}
