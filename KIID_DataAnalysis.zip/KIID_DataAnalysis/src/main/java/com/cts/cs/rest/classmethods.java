package com.cts.cs.rest;


public class classmethods {
double quarterReturn;
String shareName;
String yearList;
int year;





public String getYearList() {
	return yearList;
}

public void setYearList(String yearList) {
	this.yearList = yearList;
}

public int getYear() {
	return year;
}

public void setYear(int year) {
	this.year = year;
}

public String getShareName() {
	return shareName;
}

public void setShareName(String shareName) {
	this.shareName = shareName;
}


public double getQuarterReturn() {
	return quarterReturn;
}

public void setQuarterReturn(double quarterReturn) {
	this.quarterReturn = quarterReturn;
}


}
