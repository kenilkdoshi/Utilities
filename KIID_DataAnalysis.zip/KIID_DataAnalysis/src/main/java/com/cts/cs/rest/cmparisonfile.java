package com.cts.cs.rest;

import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import java.util.ArrayList;

import WekaIntegration.fileconversion2;
import WekaIntegration.predictFunds;

public class cmparisonfile {
	@SuppressWarnings("rawtypes")
	ArrayList arr=new ArrayList<>();
	@SuppressWarnings({ "deprecation", "unchecked", "rawtypes" })
	public ArrayList fetchdata(int year) throws Exception
	{
	
	List l=new List();
		
l.addItem("BlackRock Japan Index Sub-Fund");
l.addItem("BlackRock North America Index Sub-Fund");
l.addItem("BlackRock Pacific Index Sub-Fund");
l.addItem("BlackRock US Index Sub-Fund");
l.addItem("Emerging Markets Corporate Bond Fund");
l.addItem("European Equity Income Fund");
l.addItem("Global Inflation Linked Bond Fund");
		File file = new File("D:/KID/TestDataForAllShares.csv");
		int i=0;
		BufferedWriter bw = new BufferedWriter(new FileWriter(file.getAbsoluteFile()));
	
		String cn = "Fund" + "," + "Year" + "," + "Actual" + "," +"Benchmark";
			
		bw.append(cn);
		bw.newLine();
		int x=l.getItemCount();
		while(x!=0)
		{int y=year;
			System.out.println(x+"------"+l.getItem(i));
			for(int j=0;j<3;j++)
			{
		String content =l.getItem(i)  + "," + y + "," + "?" + "," +"?";
		y++;
		bw.append(content);
		bw.newLine();
			}
	
		i++;
		x--;
		}
		bw.close();
		
		fileconversion2 fc=new fileconversion2();
		
	// z=l.getItemCount();
fc.convert();
		
		int k=0;
		FileReader fr = new FileReader("D:/KID/TestDataForAllShares.csv");
		BufferedReader	br = new BufferedReader(fr);

	//	String sCurrentLine;
		String line = "";
        String cvsSplitBy = ",";
        List fundname = new List() ;
        List yearList=new List() ;int n=0;
		br = new BufferedReader(new FileReader("D:/KID/TestDataForAllShares.csv"));

		  while ((line = br.readLine()) != null) {

              // use comma as separator
              String[] country = line.split(cvsSplitBy);
              String a=country[0];
            //  System.out.println("Country [code= " + a + " , name=" + country[1] + "]");
fundname.add(a,n);
yearList.add(country[1],n);
             

          }

		
		predictFunds pf=new predictFunds();
		
		ArrayList<Double> r=pf.PredictedQuaterReturn();
		System.out.println(r.size());
		//List sharereturns=null;
for(int m=0;m<r.size();m++)
{
	classmethods cm=new classmethods();
	//System.out.println("---r[m]"+r.get(m));
		
			cm.setQuarterReturn(r.get(m));
			cm.setYearList( yearList.getItem(m));
			cm.setShareName(fundname.getItem(m));
			arr.add(k,cm);
}
//arr.add(0, fundname);
//arr.add(1, yearList);
//arr.add(2, r);
		
		   
			k++;
				
	return arr;
	
}

	}

