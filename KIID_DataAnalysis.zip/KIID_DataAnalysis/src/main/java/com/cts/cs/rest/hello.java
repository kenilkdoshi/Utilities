package com.cts.cs.rest;


import com.mongodb.MongoClient;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.util.JSON;

public class hello {
	DBCursor cursor=null;
   @SuppressWarnings({ "resource", "static-access" })
public DBCursor plot(){	
	   
	            MongoClient mongoClient;
	            String host= "localhost";
	            int port=27017;
	            String dbName="KIID_DB";
	           mongoClient = new MongoClient(host,port);
			  @SuppressWarnings("deprecation")
			DBCollection collection = mongoClient.getDB(dbName).getCollection("sharedata");
			 cursor = collection.find();
			 System.out.println(cursor);
			JSON json =new JSON();
         String serialize = json.serialize(cursor);
         System.out.println(serialize);
		return cursor;
        
	       }
	         
	   
   
}