package pdfReader;



import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import java.lang.String ;

/**
 * @author Himank
 *
 */

//TO BACKTRACK EXCEPTIONS REMOVE COMMENT FROM-------- e.printStackTrace() ; 
public class pdfReader {


static BufferedWriter       bw = null ;
 
{
if (file.exists())
file.delete();
}
static File file =new File("D:/KID/AllFundsDetails.csv");
static String tempStr = null ;
    /**
     * @param args
     * @throws IOException 
     *
     */
    public static void main(String[] args) 
    {
    try {
    File filename=new File("D:/KID/AllFundsDetails.csv");
            BufferedWriter out = new BufferedWriter(new FileWriter(filename));
            tempStr = "Fund Name"+","+"Year"+","+"Fund"+","+"BenchMark";
            out.write(tempStr);
            out.newLine();
            out.close();
          }
        catch (IOException e1) {
// TODO Auto-generated catch block
e1.printStackTrace();
}
    File k = new File("D:/KID/KIID_FILES");
        File[] files = k.listFiles();
    for (File file1 : files)
    {
    File f = file1; 
        System.out.println(file1.getName());
            PDDocument document ;
        
        try 
        {
            document = PDDocument.load(f);
            //New Code
            // Extract Page
            // PDPage pdPage = document.getPage(1) ;
            //New Code
            PDFTextStripper pdfStripper = new PDFTextStripper();
            String text = pdfStripper.getText(document);
            document.close() ;
            //pdfStripper.getLineSeparator() ;
            if(!parseMethod1(text, pdfStripper))
            parseMethod2(text, pdfStripper) ;
        } 
        catch (IOException e) 
        {
            // e.printStackTrace() ;
        }
    }
    }
  
    private static boolean parseMethod2(String text, PDFTextStripper pdfStripper) 
    {
        int        count=0;
        String [] yearArry = null ;
        String [] fundArry = null ;
        String [] benchmarkArry = null ;
        String    yearList = null ;
        
        try
        {
        String mm;
            String []docArry = text.split(pdfStripper.getLineSeparator()) ;
            mm=docArry[4];
            for(int i=0;i<docArry.length;i++)
            {
            if(isYearSet(docArry[i], pdfStripper.getWordSeparator()))
                {
                    yearArry = docArry[i].split(pdfStripper.getWordSeparator()) ;
                    continue ;
                }
               
                if(docArry[i].startsWith(" Fund"))
                {
                    fundArry = docArry[i].split(pdfStripper.getWordSeparator()) ;
                    String    fundList = "Fund" ;
                    
                    for(int k=0;k<fundArry.length;k++)
                    {
                        if(fundArry[k].isEmpty() || fundArry[k].contains("Fund") || !isNumeric(fundArry[k]))
                            continue ;
                        
                        fundList += "," + fundArry[k] ;
                    }
                    //System.err.println(fundList) ;
                    fundArry = fundList.split(",") ;
                   
                    continue ;
                }
               
               
                if(docArry[i].startsWith(" Benchmark"))
                {
                    benchmarkArry = docArry[i].split(pdfStripper.getWordSeparator()) ;
                    String    benchList = "Benchmark" ;
                    
                    for(int k=0;k<benchmarkArry.length;k++)
                    {
                        if(benchmarkArry[k].isEmpty() || benchmarkArry[k].contains("Benchmark") || !isNumeric(benchmarkArry[k]))
                            continue ;

                        benchList += "," + benchmarkArry[k] ;
                    }
                   // System.err.println(benchList) ;
                    benchmarkArry = benchList.split(",") ;
                    continue ;
                }
            }
            try
            {
            count = yearArry.length - fundArry.length ;
            }
            catch(Exception e)
            {
            	System.out.println("No data found in pdfs."+e);
            }
         
            if(count > 0)
            {   yearList = "Year" ;
                for(int k=count+1;k<yearArry.length;k++)
                {   yearList += "," + yearArry[k] ;
               
                }
               // System.err.println(yearList) ;
                yearArry = yearList.split(",") ;
                }
    
            //printToFileVertically("/home/Himank/parsed.csv",storeList,fundsLinePresent,benchMarkLinePresent);
            print(new File("D:/KID/AllFundsDetails.csv"),yearArry,fundArry,benchmarkArry,mm);
            }
        catch(Exception e)
        {
            e.printStackTrace() ;
            return false ;
        }
        
        return true ;
    }
    
    private static boolean isNumeric(String str)  
    {  
      try  
      {  
        Double.parseDouble(str);  
      }  
      catch(NumberFormatException nfe)  
      {  
        return false;  
      }  
      return true;  
    }

    private static boolean parseMethod1(String text, PDFTextStripper pdfStripper)
    {
        boolean    store = false ;
        boolean    fundsLinePresent = false ;
        boolean    benchMarkLinePresent = false ;
        int        count=0;
       
        try
        {
            ArrayList<String>  storeList = new ArrayList<String>() ;
            String []docArry = text.split(pdfStripper.getLineSeparator()) ;
            String nn;
            nn=docArry[0];

            for(int i=0;i<docArry.length;i++)
            { 
                       
               if(isYearSet(docArry[i], pdfStripper.getWordSeparator()))
                    {
                    store = true ;
                    }
               
                    if(store && docArry[i] != null && (docArry[i].startsWith("Fund")))
                    {
                    fundsLinePresent = true ;
                    if(docArry[i+1].startsWith("Benchmark"))
                    benchMarkLinePresent = true ;
                    store = false ;
                    break ;
                    }
               
                if(store)
                {
                    count++;
                    storeList.add(docArry[i]) ;
                }
                
            }
            count-- ;
            count = count/2;
            String yearString = storeList.get(0) ;
            String newYearString = formatYearString(yearString, count) ;
            storeList.set(0, newYearString) ;
            return printToFileVertically(file,storeList,fundsLinePresent,benchMarkLinePresent,nn);
           }
        catch(Exception e)
        {
         //   e.printStackTrace() ;
            return false ;
        }
        
    }
    private static String formatYearString(String yearString, int validYearCount)
    {       
        String [] data = yearString.split(" ");
        int       startYear = data.length - validYearCount ;
        StringBuilder sb = new StringBuilder() ;
        sb.append("Year") ;
        for(int i=startYear;i<data.length;i++)
        {
               sb.append(",").append(data[i]) ;
        }
        
        return sb.toString() ;
    }
  
    private static boolean printToFileVertically(File file,ArrayList<String> storeList,boolean fundsLinePresent, boolean benchMarkLinePresent,String fundname) 
    {
        String fund      = "Fund" ;
        String benchmark = "Benchmark" ;
        String yearList = null ;
        int    i = 0 ;
        file.exists();
        Iterator<String> iter = storeList.iterator() ;
        while(iter.hasNext())
        {
            String line = iter.next() ;
            
            if(yearList == null)
            {
                yearList = line ;
                continue ;
            }
            
            if(fundsLinePresent && benchMarkLinePresent)
            {
                if(i%2 == 0)
                    {
                fund=fund+","+line ;
                    }
               
                else
                    benchmark=benchmark+","+line ;
                i++ ;    
            }
            else
                fund=fund+","+line ;
        }
        String []yearArr = yearList.split(",") ;
        String []fundArr = fund.split(",") ;
        String []benchMarkArr = benchmark.split(",") ;
        return print(file, yearArr, fundArr, benchMarkArr,fundname) ;
    }
    
    public static boolean print(File file, String []yearArr, String []fundArr, String [] benchMarkArr,String fundname)
    {
    boolean              status = true ;
       
        try 
        {
        //System.out.println();
        //System.out.println(file);
        bw = new BufferedWriter(new FileWriter(file,true)) ;
        
            for(int k=1;k<yearArr.length;k++)
            {
                tempStr = fundname+","+yearArr[k]+","+fundArr[k]+","+benchMarkArr[k] ;
                bw.write(tempStr) ;
                bw.newLine() ;
            }
          bw.flush() ;
          bw.close() ;
        } 
        catch (FileNotFoundException e) 
        {
            // TODO Auto-generated catch block
         //   e.printStackTrace();
            status = false ;
        } 
        catch (IOException e) {
            // TODO Auto-generated catch block
         //   e.printStackTrace();
            status = false ;
        }
        catch(Exception e)
        {
           // e.printStackTrace() ;
            status = false ;
        }
        
        if(bw != null)
        {
            try 
            {
                bw.close() ;
            } 
            catch (IOException e) 
            {
                // DO Nothing
            }
        }
        return status ;
    }
    
    public static boolean isYearSet(String temp, String delim)
    {
        String [] lineArry = temp.split(delim) ;
        if(lineArry != null && lineArry.length >= 2)
        {
            for(int i=0;i<lineArry.length;i++)
            {
                if(lineArry[i].length() != 4)
                    return false ;
            }
            return true ;  
        }
        else
            return false ;
        }
    
}