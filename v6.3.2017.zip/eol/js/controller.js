var myApp=angular.module('app',['ngGrid']);
  
	myApp.controller("TabController",function(){
	    this.tab=0;
	    this.setTab=function(tabId)
	    {
	    	
	        this.tab=tabId;
	    };
	    this.isSet=function(tabId)
	    {
	        return this.tab==tabId;
	    };

	});


myApp.directive('datepicker', function() {
  return {
    link: function(scope, el, attr) {
      $(el).datepicker({
        onSelect: function(dateText) {
          console.log(dateText);
          var expression = attr.ngModel + " = " + "'" + dateText + "'";
          scope.$apply(expression);
         
          
          // how do i set this elements model property ?
        }
      });
    }
  };
});





myApp.directive('submenu', function() {
  return {
    restrict: 'AEC', /*attaches directive to class called submenu*/
    link: function(scope, elem) {
      elem.parent().bind('mouseover', function() {
        /*Displays the submenu*/
        elem.css('display', 'block');
        /*add class highlight to the class linkName.  We have to use this chain of methods because angular doesn't support .siblings()*/
        elem.parent().children().eq(0).addClass("highlight");
      });
      elem.parent().bind('mouseleave', function() {
        elem.css('display', 'none');
        elem.parent().children().eq(0).removeClass("highlight");
      });
    }
  };
});



myApp.controller("CompanyCtrl", function($scope,$http) {
	 
	
	
	$scope.myData = [{Snum: "1", TradeId: 101, FromDate: "06/05/2016",Todate:"07/04/2017",Entity:"Entity1",Status:0},
	                    {Snum: "2", TradeId: 102, FromDate: "06/05/2016",Todate:"07/04/2017",Entity:"Entity2",Status:1},
	                    {Snum: "3", TradeId: 103, FromDate: "06/07/2016",Todate:"07/06/2017",Entity:"Entity3",Status:0},
	                    {Snum: "4", TradeId: 104, FromDate: "06/07/2016",Todate:"07/07/2017",Entity:"Entity4",Status:1},
	                    {Snum: "5", TradeId: 105, FromDate: "06/08/2016",Todate:"07/08/2017",Entity:"Entity5",Status:0},
						 {Snum: "6", TradeId: 106, FromDate: "06/09/2016",Todate:"07/09/2017",Entity:"Entity6",Status:1},
						 {Snum: "7", TradeId: 107, FromDate: "06/10/2016",Todate:"07/10/2017",Entity:"Entity7",Status:0},
						 {Snum: "8", TradeId: 108, FromDate: "06/11/2016",Todate:"07/11/2017",Entity:"Entity8",Status:1},
						 {Snum: "9", TradeId: 109, FromDate: "06/12/2016",Todate:"07/12/2017",Entity:"Entity9",Status:0},
						 {Snum: "10", TradeId: 110, FromDate: "06/13/2016",Todate:"07/13/2017",Entity:"Entity10",Status:1},
						 {Snum: "11", TradeId: 111, FromDate: "06/14/2016",Todate:"07/14/2017",Entity:"Entity11",Status:0},
						 {Snum: "12", TradeId: 112, FromDate: "06/15/2016",Todate:"07/15/2017",Entity:"Entity12",Status:1}];
	 
	 
	   

	   $scope.Entity = ["Entity1", "Entity2", "Entity3","Entity4","Entity5","Entity6","Entity7","Entity8","Entity9","Entity10","Entity11","Entity12"];
	    $scope.startDate='';
	    $scope.EndDate='';
	    $scope.selectedEntity='';
	    $scope.var1='';
	   
	   
	  
	
	   
	   $scope.filterOptions = {
			    filterText: '',
			    useExternalFilter: true
			  };
	   
	   $scope.pagingOptions = {
		        pageSizes: [2, 4, 6],
		        pageSize: 10,
		        totalServerItems: 0,
		        currentPage: 1
		    };  
	   
	   
	   $scope.setPagingData = function(data, page, pageSize){	
	        var pagedData = data.slice((page - 1) * pageSize, page * pageSize);
	        $scope.myData1 = pagedData;
	        $scope.pagingOptions.totalServerItems = data.length;
	        if (!$scope.$$phase) {
	            $scope.$apply();
	        }
	    };
	    $scope.getPagedDataAsync = function (pageSize, page, searchText) {
	        setTimeout(function () {
	        	var data1;

	            if (searchText) {
	                var ft = searchText.toLowerCase();
	                $http.get('http://jsonplaceholder.typicode.com/posts/').success(function (largeLoad) {		
	                    data1 = largeLoad.filter(function(item) {
	                        return JSON.stringify(item).toLowerCase().indexOf(ft) != -1;
	                    });
	                    $scope.setPagingData(data1,page,pageSize);
	                });            
	            } else {
	                $http.get('http://jsonplaceholder.typicode.com/posts/').success(function (largeLoad) {
	                    $scope.setPagingData(largeLoad,page,pageSize);
	                });
	            }
	        }, 100);
	    };
		
	  //  $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage);
		
	    $scope.$watch('pagingOptions', function () {
	    //	console.log("claasssic"+data1);
	        console.log( "watch changed pagingOptions" );
	        $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
	    }, true);
	   // $scope.$watch('filterOptions', function () {
	    //    $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText);
	  //  }, true);   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	   
	  
			  
			  $scope.activateFilter = function() {
			    var Entity = $scope.filterEntity || null;
			    var Todate = ($scope.filterTodate) ? $scope.filterTodate.toString() : null;
			    var FromDate = ($scope.filterFromDate) ? $scope.filterFromDate.toString() : null;
			  //  if (!Entity && !Todate) Entity='';
			    
			    $scope.filterData = angular.copy($scope.myData, []);
			    $scope.filterData = $scope.filterData.filter( function(item) {
			    	if(Todate==null || FromDate==null)
			    		return (item.Entity.indexOf(Entity)>-1);
			    	if(Todate==null)
			    		return ( item.FromDate.toString().indexOf(FromDate) > -1);
			    	
			    	
			    	// return (item.Entity.indexOf(Entity)>-1 && item.Todate.toString().indexOf(Todate) > -1 ||  item.FromDate.toString().indexOf(FromDate) > -1);
			    });
			  };
			    
			 
			  $scope.filterData = angular.copy($scope.myData, []);
	   $scope.gridOptions = { data: 'myData',filterOptions: $scope.filteroptions , enablePaging: true,
		        pagingOptions: $scope.pagingOptions,showFooter: true, 
			   rowTemplate: '<div style="height: 100%" ng-class="{green: row.getProperty(\'Status\') == 1}"><div ng-style="{ \'cursor\': row.cursor }" ng-repeat="col in renderedColumns" ng-class="col.colIndex()" class="ngCell ">' +
	           '<div class="ngVerticalBar" ng-style="{height: rowHeight}" ng-class="{ ngVerticalBarVisible: !$last }"> </div>' +
	            '<div ng-cell></div>' +
	     '</div></div>'
	        };
	    
	    $scope.reset=function(){
	    	 $scope.filterTodate=' ';
	    	 $scope.filterEntity=' ';
	    	 $scope.filterFromDate=' ';
	    	 $scope.Var1=' ';
		    }
	    
	    $scope.Submit=function(){
	      
	    console.log($scope.startDate);
	    console.log($scope.EndDate);
	    console.log($scope.selectedEntity);
	    console.log($scope.Var1);
	    }
});



